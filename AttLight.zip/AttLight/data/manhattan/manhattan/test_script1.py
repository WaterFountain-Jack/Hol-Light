import os

import cityflow
import json

config = {
    "interval": 1.0,
    "seed": 0,
    "dir": "./",
    "roadnetFile": "roadnet_manhattan.json",
    "flowFile": "manhattan_7846.json",
    "rlTrafficLight": True,
    "saveReplay": True,
    "roadnetLogFile": "frontend/web/roadnetLogFile.json",
    "replayLogFile": "frontend/web/replayLogFile.txt"
}
config1 = {
    "interval": 1.0,
    "seed": 0,
    "dir": "./",
    "roadnetFile": "roadnet_4_4.json",
    "flowFile": "anon_4_4_hangzhou_real.json",
    "rlTrafficLight": True,
    "saveReplay": True,
    "roadnetLogFile": "roadnetLogFile.json",
    "replayLogFile": "frontend/web/replayLogFile.txt"
}

with open('config.json', 'w') as fp:
    json.dump(config, fp)

config_path = 'config.json'
eng = cityflow.Engine(config_path, thread_num=1)

# print(eng.get_lane_vehicles())

# for i in range(100):

file = os.path.join(config["dir"], config["roadnetFile"])
for i in range(10):
    index = 0;
    with open('{0}'.format(file)) as json_data:

        net = json.load(json_data)
        for inter in net['intersections']:
            if not inter['virtual']:
                eng.set_tl_phase(inter['id'], 0)
                eng.next_step()

                print("第" + str(i) + "伦:" + "成功: " + str(index))
                index += 1





import os
import cityflow
import json
import numpy as np


MAX = float('inf')

#https://blog.csdn.net/qq_62789540/article/details/126044970

def dijkstra(matrix, start_node,end_node):
    matrix_length = len(matrix)  # 矩阵一维数组的长度，即节点的个数

    used_node = [False] * matrix_length  # 访问过的节点数组

    pre_node = [-1] * matrix_length

    distance = [MAX] * matrix_length  # 最短路径距离数组

    distance[start_node] = 0  # 初始化，将起始节点的最短路径修改成0

    # 将访问节点中未访问的个数作为循环值，其实也可以用个点长度代替。
    while used_node.count(False):
        min_value = MAX
        min_value_index = -1

        # 在最短路径节点中找到最小值，已经访问过的不在参与循环。
        # 得到最小值下标，每循环一次肯定有一个最小值
        for index in range(matrix_length):
            if not used_node[index] and distance[index] < min_value:
                min_value = distance[index]
                min_value_index = index
        #这里的地图不都是联通的，所以可能会有走不到的情况
        if(min_value >= MAX):
            return []
        if(min_value_index == end_node):
            end_linshi = end_node
            ans = []
            while(pre_node[end_linshi] != -1):
                ans.append(end_linshi)
                end_linshi = pre_node[end_linshi]
            ans.append(start_node)
            #反转一下
            ans = ans[::-1]
            return ans

        # 将访问节点数组对应的值修改成True，标志其已经访问过了
        used_node[min_value_index] = True

        # 更新distance数组。
        # 以B点为例：distance[x] 起始点达到B点的距离。
        # distance[min_value_index] + matrix[min_value_index][index] 是起始点经过某点达到B点的距离，比较两个值，取较小的那个。
        for index in range(matrix_length):
            if(matrix[min_value_index][index] == -1):
                continue
            if(distance[min_value_index] + matrix[min_value_index][index] < distance[index]):
                distance[index] = distance[min_value_index] + matrix[min_value_index][index]
                pre_node[index] = min_value_index
    return []

city = "newyork16_3"#jinan hangzhou newyork16_3 newyork28_7 manhattan SH1 SH2

if "jinan" in city:
    dir = "./Jinan/3_4"
    roadnetFile = "roadnet_3_4.json"
    flowFile = ["anon_3_4_jinan_real", "anon_3_4_jinan_real_2000", "anon_3_4_jinan_real_2500"]
    broken_roads = ["road_2_2_0"]
elif "hangzhou" in city:
    dir = "./Hangzhou/4_4"
    roadnetFile= "roadnet_4_4.json"
    flowFile = ["anon_4_4_hangzhou_real","anon_4_4_hangzhou_real_5734","anon_4_4_hangzhou_real_5816"]
    broken_roads = ["road_2_2_0"]

elif "newyork16_3" in city:
    dir = "./NewYork/16_3"
    roadnetFile = "roadnet_16_3.json"
    flowFile = ["anon_16_3_newyork_real"]
    broken_roads = ["road_4_13_2"]
elif "newyork28_7" in city:
    dir = "./NewYork/28_7"
    roadnetFile = "roadnet_28_7.json"
    flowFile = ["anon_28_7_newyork_real_double","anon_28_7_newyork_real3"]
    broken_roads = ["road_4_13_2"]
elif "manhattan" in city:
    a = 1
elif "SH1" in city:
    a = 1
elif "SH2" in city:
    a = 1


print("不包含的路为",broken_roads)
for a_flowFile in flowFile:
    config = {
        "dir": dir,
        "roadnetFile":roadnetFile,
        "flowFile": a_flowFile+".json",
    }
    roadnet_file = os.path.join(config["dir"], config["roadnetFile"])
    roads_dic = {}
    idx_dic={}

    with open('{0}'.format(roadnet_file)) as json_data:
        net = json.load(json_data)
        for idx,road in enumerate(net['roads']) :
            roads_dic[road['id']] = idx
            idx_dic[idx] = road['id']

    roads_num = len(roads_dic)

    matrix = [[-1 for _ in range(roads_num)] for _ in range(roads_num)]

    with open('{0}'.format(roadnet_file)) as json_data:
        net = json.load(json_data)
        for interseciton in net['intersections'] :
            for roadlink in interseciton["roadLinks"]:
                #坏掉的路就不能通行
                if(roadlink["startRoad"] in broken_roads or roadlink["endRoad"] in broken_roads):
                    continue
                startRoad_idx = roads_dic[roadlink["startRoad"]]
                endRoad_idx = roads_dic[roadlink["endRoad"]]
                matrix[startRoad_idx][endRoad_idx] = 1
    # print(matrix)



    flow_file = os.path.join(config["dir"], config["flowFile"])

    cont = 0
    with open('{0}'.format(flow_file)) as json_data:
        flows = json.load(json_data)
        for flow in flows:
            for broken_road in broken_roads:
                if(broken_road in flow["route"]):
                    cont = cont + 1
                    startRoad = flow["route"][0]
                    endRoad = flow["route"][-1]
                    startRoad_idx = roads_dic[startRoad]
                    endRoad_idx = roads_dic[endRoad]


                    #注意这里的dijkstra算法最短路径为最少的车道数量，没有把车道的长度考虑进去
                    flow_idx = dijkstra(matrix,startRoad_idx,endRoad_idx)
                    flow_route = [idx_dic[linshi] for linshi in flow_idx]
                    if ((broken_road == startRoad) | (broken_road == endRoad)):
                        flow_route = []
                        flows.remove(flow)
                        print("出现在开头或是结尾")
                    else:
                        flow["route"] = flow_route
                    #更改flow中的route项
                    # flow["route"] = flow_route
                    print(flow)


        new_flow_file = os.path.join(config["dir"], a_flowFile+"new.json")
        with open(new_flow_file, "w") as f:
            json.dump(flows, f)
            print("加载入文件完成...")

    print("最后改变的有：",cont,"辆车")










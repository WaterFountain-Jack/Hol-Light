import json
import os
import shutil
import random

from utils.PG_generator_AC import PG_generator_AC
from utils.G_generator import G_generator
from utils.PG_generator_A import PG_generator_A
from utils.AttentionLight_generator import AttentionLight_generator
from utils.AttentionLightOldState_generator import AttentionLightOldState_generator

class cenlight_pipeline:
    def _path_check(self):
        # check path
        if os.path.exists(self.dic_path["PATH_TO_WORK_DIRECTORY"]):
            if self.dic_path["PATH_TO_WORK_DIRECTORY"] != "records/default":
                raise FileExistsError
            else:
                pass
        else:
            os.makedirs(self.dic_path["PATH_TO_WORK_DIRECTORY"])

        if os.path.exists(self.dic_path["PATH_TO_MODEL"]):
            if self.dic_path["PATH_TO_MODEL"] != "model/default":
                raise FileExistsError
            else:
                pass
        else:
            os.makedirs(self.dic_path["PATH_TO_MODEL"])

        if os.path.exists(self.dic_path["PATH_TO_PRETRAIN_WORK_DIRECTORY"]):
            pass
        else:
            os.makedirs(self.dic_path["PATH_TO_PRETRAIN_WORK_DIRECTORY"])

        if os.path.exists(self.dic_path["PATH_TO_PRETRAIN_MODEL"]):
            pass
        else:
            os.makedirs(self.dic_path["PATH_TO_PRETRAIN_MODEL"])
    def _copy_conf_file(self, path=None):
        # write conf files
        if path == None:
            path = self.dic_path["PATH_TO_WORK_DIRECTORY"]
        json.dump(self.dic_exp_conf, open(os.path.join(path, "exp.conf"), "w"),
                  indent=4)
        json.dump(self.dic_agent_conf, open(os.path.join(path, "agent.conf"), "w"),
                  indent=4)
        json.dump(self.dic_traffic_env_conf,
                  open(os.path.join(path, "traffic_env.conf"), "w"), indent=4)
    def _copy_anon_file(self, path=None):
        # hard code !!!
        if path == None:
            path = self.dic_path["PATH_TO_WORK_DIRECTORY"]
        # copy sumo files

        shutil.copy(os.path.join(self.dic_path["PATH_TO_DATA"], self.dic_exp_conf["TRAFFIC_FILE"][0]),
                        os.path.join(path, self.dic_exp_conf["TRAFFIC_FILE"][0]))
        shutil.copy(os.path.join(self.dic_path["PATH_TO_DATA"], self.dic_exp_conf["ROADNET_FILE"]),
                    os.path.join(path, self.dic_exp_conf["ROADNET_FILE"]))

    def __init__(self, dic_exp_conf, dic_agent_conf, dic_traffic_env_conf, dic_path):

        # load configurations
        self.dic_exp_conf = dic_exp_conf
        self.dic_agent_conf = dic_agent_conf
        self.dic_traffic_env_conf = dic_traffic_env_conf
        self.dic_path = dic_path

        # do file operations
        self._path_check()
        self._copy_conf_file()
        self._copy_anon_file()
        # test_duration
        self.test_duration = []

        sample_num = 10 if self.dic_traffic_env_conf["NUM_INTERSECTIONS"]>=10 else min(self.dic_traffic_env_conf["NUM_INTERSECTIONS"], 9)
        print("sample_num for early stopping:", sample_num)
        self.sample_inter_id = random.sample(range(self.dic_traffic_env_conf["NUM_INTERSECTIONS"]), sample_num)

    def run(self, multi_process=False):


    #Glight ad_GLight PGLight_A PGLight_AC ad_PGLight_adA ad_PGLight_adAC PGLight_adA PGLight_adAC(PGLight)
        f_time = open(os.path.join(self.dic_path["PATH_TO_WORK_DIRECTORY"],"running_time.csv"),"w")
        f_time.write("generator_time\tmaking_samples_time\tupdate_network_time\ttest_evaluation_times\tall_times\n")
        f_time.close()

        if self.dic_agent_conf['AGENT_NAME'] in ['GLight','ad_GLight']:
            cenlight_runner = G_generator(self.dic_exp_conf, self.dic_agent_conf, self.dic_traffic_env_conf,
                                              self.dic_path)
        elif self.dic_agent_conf['AGENT_NAME'] in ['PGLight_A','ad_PGLight_adA','PGLight_adA']:
            cenlight_runner = PG_generator_A(self.dic_exp_conf, self.dic_agent_conf, self.dic_traffic_env_conf,
                                              self.dic_path)
        elif self.dic_agent_conf['AGENT_NAME'] in ['ad_PGLight_adAC','PGLight_adAC']:
            cenlight_runner = PG_generator_AC(self.dic_exp_conf, self.dic_agent_conf, self.dic_traffic_env_conf, self.dic_path)
        elif self.dic_agent_conf['AGENT_NAME'] in ['AttentionLight','AttentionLightAllLane',"AttentionLightADPressure","AttentionLightManyFeatures"]:
            cenlight_runner = AttentionLight_generator(self.dic_exp_conf, self.dic_agent_conf, self.dic_traffic_env_conf, self.dic_path)
        elif self.dic_agent_conf['AGENT_NAME'] in ['AttentionLightADPressureOldState']:
            cenlight_runner = AttentionLightOldState_generator(self.dic_exp_conf, self.dic_agent_conf, self.dic_traffic_env_conf, self.dic_path)

        cenlight_runner.run()
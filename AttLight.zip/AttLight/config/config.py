# ATTENTIONLIGHT Glight ad_GLight PGLight_A PGLight_AC ad_PGLight_adA ad_PGLight_adAC PGLight_adA PGLight_adAC(PGLight)
from agent.AttentionLightADPressureOldState import AttentionLightADPressureOldState
from agent.AttentionLightAllLane import AttentionLightAllLane
from agent.AttentionLight import AttentionLight
from agent.AttentionLightADPressure import AttentionLightADPressure
from agent.AttentionLightManyFeatures import AttentionLightManyFeatures
DIC_AGENT = {
    "AttentionLightAllLane":AttentionLightAllLane,
    "AttentionLight":AttentionLight,
    "AttentionLightADPressure":AttentionLightADPressure,
    "AttentionLightManyFeatures":AttentionLightManyFeatures,
    "AttentionLightADPressureOldState":AttentionLightADPressureOldState
}
DIC_ATTENTIONLIGHTADPRESSUREOLDSTATE_AGENT_CONF={
    "AGENT_NAME":"AttentionLightADPressureOldState",
    "LIST_STATE_FEATURE": [
        "traffic_movement_pressure_queue_efficient_lane_enter_running_part",
        "all_phase_by_entering_lane_double",
        "mask",
        "cur_phase",
        "ad_old_state"
    ]
}
DIC_ATTENTIONLIGHTMANYFEATURES_AGENT_CONF={
    "AGENT_NAME":"AttentionLightManyFeatures",
    "LIST_STATE_FEATURE": [
        "traffic_movement_pressure_queue_efficient_lane_enter_running_part_lane_num_vehicle",
        "all_phase_by_entering_lane_triple",
        "mask",
        "cur_phase"
    ]
}
DIC_ATTENTIONLIGHTADPRESSURE_AGENT_CONF={
    "AGENT_NAME":"AttentionLightADPressure",
    "LIST_STATE_FEATURE": [
        "lane_num_vehicle",
        "traffic_movement_pressure_queue_efficient",
        "lane_enter_running_part",
        "all_phase_by_entering_lane",
        "mask"
    ]
}

DIC_ATTENTIONLIGHTALLLANE_AGENT_CONF = {
    "AGENT_NAME":"AttentionLightAllLane",
    "LIST_STATE_FEATURE": [
        "all_lane_num_vehicle",
        "all_phase_by_all_lane",
        "mask",
    ]
}

DIC_ATTENTIONLIGHT_AGENT_CONF = {
    "AGENT_NAME":"AttentionLight",
    "LIST_STATE_FEATURE": [
        "lane_num_vehicle",
        "all_phase_by_entering_lane",
        "mask",
        "cur_phase"
    ]
}


DIC_GLIGHT_AGENT_CONF = {
    "AGENT_NAME":"GLight",
    "LIST_STATE_FEATURE": [
        "cur_phase",
        "time_this_phase",
        "lane_num_vehicle",
        "mask",
        "all_phase_by_entering_lane",
    ]
}

DIC_AD_GLIGHT_AGENT_CONF = {
    "AGENT_NAME":"ad_GLight",
    "LIST_STATE_FEATURE": [
        "cur_phase",
        "time_this_phase",
        "traffic_movement_pressure_queue_efficient_lane_enter_running_part",
        "mask",
        "all_phase_by_entering_lane",
    ]
}

DIC_PGLIGHT_A_AGENT_CONF = {
    "AGENT_NAME":"PGLight_A",
    "LIST_STATE_FEATURE": [
        "cur_phase",
        "time_this_phase",
        "lane_num_vehicle",
        "mask",
        "all_phase_by_entering_lane",
        "old_state"
    ],
}

DIC_PGLIGHT_AC_AGENT_CONF = {
    "AGENT_NAME":"PGLight_AC",
    "LIST_STATE_FEATURE": [
        "cur_phase",
        "time_this_phase",
        "lane_num_vehicle",
        "mask",
        "all_phase_by_entering_lane",
        "old_state"
    ]
}

DIC_AD_PGLIGHT_ADA_AGENT_CONF = {
    "AGENT_NAME":"ad_PGLight_adA",
    "LIST_STATE_FEATURE": [
        "cur_phase",
        "time_this_phase",
        "traffic_movement_pressure_queue_efficient_lane_enter_running_part",
        "mask",
        "all_phase_by_entering_lane",
        "ad_old_state"
    ]
}

DIC_AD_PGLIGHT_ADAC_AGENT_CONF = {
    "AGENT_NAME":"ad_PGLightadAC",
    "LIST_STATE_FEATURE": [
        "cur_phase",
        "time_this_phase",
        "traffic_movement_pressure_queue_efficient_lane_enter_running_part",
        # "list_entering_num_l",
        "mask",
        "all_phase_by_entering_lane",
        "ad_old_state"
    ],
}

DIC_PGLIGHT_ADA_AGENT_CONF = {
    "AGENT_NAME":"PGLight_adA",
    "LIST_STATE_FEATURE": [
        "cur_phase",
        "time_this_phase",
        "lane_num_vehicle",
        "mask",
        "all_phase_by_entering_lane",
        "ad_old_state"
    ]
}

DIC_PGLIGHT_ADAC_AGENT_CONF = {
    "AGENT_NAME":"PGLightadAC",
    "LIST_STATE_FEATURE": [
        "cur_phase",
        "time_this_phase",
        "lane_num_vehicle",
        # "list_entering_num_l",
        "mask",
        "all_phase_by_entering_lane",
        "ad_old_state"
    ],
}

DIC_EXP_CONF = {
    "RUN_COUNTS": 3600,
}


dic_traffic_env_conf = {
    "ACTION_PATTERN": "set",
    "NUM_INTERSECTIONS": 1,
    "OBS_LENGTH": 167,#111
    "MIN_ACTION_TIME": 15,#15
    "MEASURE_TIME": 15,#15
    "YELLOW_TIME": 5,
    "ALL_RED_TIME": 0,
    "NUM_PHASES": 2,
    "NUM_LANES": 1,
    "ACTION_DIM": 2,
    "INTERVAL": 1,

    "DIC_REWARD_INFO": {
        "flickering": 0,
        "sum_lane_queue_length": 0,
        "sum_lane_wait_time": 0,
        "sum_lane_num_vehicle_left": 0,
        "sum_duration_vehicle_left": 0,
        "sum_num_vehicle_been_stopped_thres01": 0,
        "sum_num_vehicle_been_stopped_thres1": -0.25,
        "pressure": 0,
    },
}

DIC_PATH = {
    "PATH_TO_MODEL": "model/default",
    "PATH_TO_WORK_DIRECTORY": "records/default",
    "PATH_TO_DATA": "data/template",
    "PATH_TO_PRETRAIN_MODEL": "model/default",
    "PATH_TO_PRETRAIN_WORK_DIRECTORY": "records/default",
    "PATH_TO_PRETRAIN_DATA": "data/template",
    "PATH_TO_AGGREGATE_SAMPLES": "records/initial",
    "PATH_TO_ERROR": "errors/default"
}

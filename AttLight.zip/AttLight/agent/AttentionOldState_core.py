import math

import numpy as np

import torch
import torch.nn as nn
from torch.nn import Transformer
from torch.autograd import Variable
from torch.distributions.normal import Normal
from torch.distributions.categorical import Categorical

from torch.nn import functional as F

torch.set_printoptions(threshold=np.inf)
# 或是torch.set_printoptions(profile="full")

class Actor(nn.Module):

    def _distribution(self, obs):
        raise NotImplementedError

    def _log_prob_from_distribution(self, pi, act):
        raise NotImplementedError

    def forward(self, obs,intersection,raw,col, act=None):
        # Produce action distributions for given observations, and
        # optionally compute the log likelihood of given actions under
        # those distributions.
        pi = self._distribution(obs)
        logp_a = None
        if act is not None:
            logp_a = self._log_prob_from_distribution(pi, act)
        return pi, logp_a

#维度变化为hidden_sizes
class Actor_front(nn.Module):
    def __init__(self, obs_dim, hidden_sizes):
        super(Actor_front, self).__init__()

        weight_tensor=torch.randn(obs_dim,hidden_sizes)

        bais_tensor=torch.randn(hidden_sizes)
        self.weights=nn.Parameter(weight_tensor,requires_grad=True)
        self.bais=nn.Parameter(bais_tensor,requires_grad=True)
        nn.init.normal_(self.weights, mean=0, std=1)
        nn.init.constant_(self.bais, val=0.1)


    def forward(self, x):
        return torch.matmul(x,self.weights)+self.bais

class MLPCategoricalActor(Actor):
    def __init__(self, obs_dim,old_dim, num_lane, num_phase, hidden_sizes):
        super().__init__()
        self.obs_dim = obs_dim
        self.old_dim = old_dim
        self.num_lane = num_lane
        self.num_phase=num_phase
        self.hidden_sizes=64
        self.lstm = nn.LSTM(self.old_dim,self.old_dim,batch_first=True)
        self.attention0 = nn.MultiheadAttention(self.old_dim,4,batch_first=True)
        self.layernomn = torch.nn.LayerNorm(obs_dim)
        #加上了cur_phase
        self.mlp = Actor_front(self.obs_dim,self.hidden_sizes)
        self.attention1 = nn.MultiheadAttention(self.hidden_sizes, 4, batch_first=True)
        self.output_layer1 = Actor_front(self.hidden_sizes+1,1)
        self.relu = nn.ReLU()


    def mysfotmax(self,x, mask):

        x = torch.mul(x, torch.tensor(mask))
        ##****增加了减去最大值的步骤
        max = torch.max(x,dim = 1)[0]
        max = torch.unsqueeze(max, dim=1)
        max = [max for i in range(len(mask[0]))]
        max = torch.cat(max, dim=1)
        x = torch.sub(x, max)

        x = torch.exp(x)
        sum = torch.sum(x, dim=1)
        sum = torch.unsqueeze(sum, dim=1)
        sum = [sum for i in range(len(mask[0]))]
        sum = torch.cat(sum, dim=1)
        x = torch.div(x, torch.as_tensor(sum))
        return x


    #obs：[12,12]

    def forward(self, obs_input,all_phase_state, mask,cur_phase,old_state):
        obs_input = torch.unsqueeze(obs_input,1)
        old_state,_ = self.lstm(old_state)
        obs_input,_ = self.attention0(obs_input,old_state,old_state)
        obs_input = torch.squeeze(obs_input)
        all_phase_state = torch.as_tensor(all_phase_state,dtype=torch.float32)
        obs_input = self.layernomn(obs_input)
        # print(obs_input)
        #[12,4,12]
        obs_input_expand = torch.stack([obs_input for _ in range(self.num_phase)],axis = 1)
        #[12,4,12]
        obs_input_expand = torch.mul(obs_input_expand,all_phase_state)

        # ##当前相位后面加上1
        # #[12,4,1]
        # list_cur_pahse = []
        # for i in range(len(all_phase_state)):
        #     a_list_cur_pahse = [0 for _ in range(self.num_phase)]
        #     #给当前相位的那个相位变为1
        #     a_list_cur_pahse[cur_phase[i]] = 1
        #     list_cur_pahse.append(a_list_cur_pahse)
        # list_cur_pahse = torch.as_tensor(list_cur_pahse,dtype=torch.float32)
        # list_cur_pahse = torch.unsqueeze(list_cur_pahse,-1)
        #
        # obs_input_expand = torch.cat([obs_input_expand,list_cur_pahse],axis = -1)
        # obs_input_expand = self.layernomn(obs_input_expand)
        # print("obs_input_expand:",obs_input_expand)

        #增加一个mlp层，看看会不会再梯度爆炸
        obs_input_expand = self.mlp(obs_input_expand)
        obs_attention,_ = self.attention1(obs_input_expand, obs_input_expand, obs_input_expand)

        ##当前相位后面加上1
        # [12,4,1]
        list_cur_pahse = []
        for i in range(len(all_phase_state)):
            a_list_cur_pahse = [0 for _ in range(self.num_phase)]
            # 给当前相位的那个相位变为1
            a_list_cur_pahse[cur_phase[i]] = 1
            list_cur_pahse.append(a_list_cur_pahse)
        list_cur_pahse = torch.as_tensor(list_cur_pahse, dtype=torch.float32)
        list_cur_pahse = torch.unsqueeze(list_cur_pahse, -1)
        obs_attention = torch.cat([obs_attention,list_cur_pahse],axis = -1)

        output = self.output_layer1(obs_attention)
        output = output.squeeze()

        # output = self.relu(output)
        # print(output)
        output = self.mysfotmax(output,mask)
        # print(output)
        # print(output)
        return output

    def _log_prob_from_distribution(self, pi, act):
            return pi.log_prob(act)


class MLPCritic(nn.Module):

    def __init__(self, obs_dim, old_dim, hidden_sizes, activation):
        super().__init__()
        self.attention = nn.MultiheadAttention(old_dim,4,batch_first=True)
        self.l1 = nn.Linear(obs_dim,100)
        a=self.l1.weight
        nn.init.normal_(a,mean=0,std=0.01)
        b=self.l1.bias
        nn.init.constant_(b,val=0.01)
        self.v= nn.Linear(100,1)
        self.v_net=nn.Sequential(self.l1, self.v)

    def forward(self, obs,old_state):
        obs = torch.unsqueeze(obs,1)
        obs,_ = self.attention(obs,old_state,old_state)
        obs = torch.squeeze(obs)
        return self.v_net(obs)  # Critical to ensure v has right shape.

class MLPActorCritic(nn.Module):

    ##observation_space:21 action_space:4
    def __init__(self,obs_dim, old_dim,num_lanes,num_phases,
                 hidden_sizes=(64, 64), activation=nn.Tanh):
        super().__init__()
        self.obs_dim = obs_dim
        self.old_dim = old_dim


        self.v = MLPCritic(self.obs_dim,self.old_dim, hidden_sizes, activation)
        self.num_lanes = num_lanes
        self.num_phases = num_phases
        ###obs_dim:21 action_space:4 hidden_sizes[0]:64
        self.pi = MLPCategoricalActor(self.obs_dim,self.old_dim,self.num_lanes, self.num_phases, hidden_sizes[0])
        self.oldpi=MLPCategoricalActor(self.obs_dim,self.old_dim,self.num_lanes, self.num_phases, hidden_sizes[0])
        for k,value in self.oldpi.named_parameters():
            value.requires_grad=False

    #intersection 是intersection的个数
    #obs:12* 21  inters:12
    def step(self, state_input,all_phase_state,mask,cur_phase,old_state):
        with torch.no_grad():
            pi = self.pi(state_input,all_phase_state,mask,cur_phase,old_state)
        return pi

    def get_v(self,obs,old_state):
        v = self.v(obs,old_state)
        return v

    # def act(self, obs):
    #     return self.step(obs)[0]

    #A优势函数 减去了基线 base
    def compute_advantage(self,state,reward,old_state):
        v=self.v(state,old_state)
        v=torch.reshape(v,[-1,1])

        return reward-v

    def update_oldpi(self):
        print(self.oldpi.load_state_dict)
        self.oldpi.load_state_dict(self.pi.state_dict())
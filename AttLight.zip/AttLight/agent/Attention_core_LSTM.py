import math

import numpy as np

import torch
import torch.nn as nn
from torch.nn import Transformer
from torch.autograd import Variable
from torch.distributions.normal import Normal
from torch.distributions.categorical import Categorical

from torch.nn import functional as F




class Actor(nn.Module):

    def _distribution(self, obs):
        raise NotImplementedError

    def _log_prob_from_distribution(self, pi, act):
        raise NotImplementedError

    def forward(self, obs,intersection,raw,col, act=None):
        # Produce action distributions for given observations, and
        # optionally compute the log likelihood of given actions under
        # those distributions.
        pi = self._distribution(obs)
        logp_a = None
        if act is not None:
            logp_a = self._log_prob_from_distribution(pi, act)
        return pi, logp_a

#维度变化为hidden_sizes
class Actor_front(nn.Module):
    def __init__(self, obs_dim, hidden_sizes):
        super(Actor_front, self).__init__()

        weight_tensor=torch.randn(obs_dim,hidden_sizes)

        bais_tensor=torch.randn(hidden_sizes)
        self.weights=nn.Parameter(weight_tensor,requires_grad=True)
        self.bais=nn.Parameter(bais_tensor,requires_grad=True)
        nn.init.normal_(self.weights, mean=0, std=1)
        nn.init.constant_(self.bais, val=0.1)


    def forward(self, x):
        return torch.matmul(x,self.weights)+self.bais

class MLPCategoricalActor(Actor):
    def __init__(self, obs_dim, num_lane, num_phase, hidden_sizes):
        super().__init__()
        self.obs_dim=obs_dim
        self.num_lane = num_lane
        self.num_phase=num_phase
        self.hidden_sizes=64
        # self.mlp = Actor_front(self.obs_dim,self.hidden_sizes)
        # self.mlp = nn.Linear(self.obs_dim,self.hidden_sizes)
        self.lstm = nn.LSTM(self.obs_dim,self.hidden_sizes)
        self.attention = nn.MultiheadAttention(self.hidden_sizes,4,batch_first=True)
        self.output_layer1 = Actor_front(self.hidden_sizes,1)
        self.softmax = nn.Softmax(dim=-1)


    def mysfotmax(self,x, mask):
        x = torch.exp(x)
        x = torch.mul(x, torch.tensor(mask))
        sum = torch.sum(x, dim=1)
        sum = torch.unsqueeze(sum, dim=1)
        sum = [sum for i in range(len(mask[0]))]
        sum = torch.cat(sum, dim=1)
        x = torch.div(x, torch.as_tensor(sum))
        return x


    #obs：[12,12]

    def forward(self, obs_input,all_phase_state, mask):
        all_phase_state = torch.as_tensor(all_phase_state,dtype=torch.float32)
        #[12,4,12]
        obs_input_expand = torch.stack([obs_input for _ in range(self.num_phase)],axis = 1)
        #[12,4,12]
        obs_input_expand = torch.mul(obs_input_expand,all_phase_state)

        # obs_input_expand = self.mlp(obs_input_expand)
        # print(list(self.mlp.parameters()))
        #这里还可以加上传递隐形参数的功能
        obs_lstm,_ = self.lstm(obs_input_expand)

        output = self.output_layer1(obs_lstm)
        output = output.squeeze()
        output = self.softmax(output)
        # output = self.mysfotmax(output,mask)
        # print(output)
        return output

    def _log_prob_from_distribution(self, pi, act):
            return pi.log_prob(act)


class MLPCritic(nn.Module):

    def __init__(self, obs_dim, hidden_sizes, activation):
        super().__init__()
        self.l1 = nn.Linear(obs_dim,100)
        a=self.l1.weight
        nn.init.normal_(a,mean=0,std=0.01)
        b=self.l1.bias
        nn.init.constant_(b,val=0.01)
        self.v= nn.Linear(100,1)
        self.v_net=nn.Sequential(self.l1, self.v)

    def forward(self, obs,intersection):
        return self.v_net(obs)  # Critical to ensure v has right shape.

class MLPActorCritic(nn.Module):

    ##observation_space:21 action_space:4
    def __init__(self,obs_dim, num_lanes,num_phases,
                 hidden_sizes=(64, 64), activation=nn.Tanh):
        super().__init__()
        self.obs_dim = obs_dim


        self.v = MLPCritic(self.obs_dim, hidden_sizes, activation)
        self.num_lanes = num_lanes
        self.num_phases = num_phases
        ###obs_dim:21 action_space:4 hidden_sizes[0]:64
        self.pi = MLPCategoricalActor(self.obs_dim,self.num_lanes, self.num_phases, hidden_sizes[0])
        self.oldpi=MLPCategoricalActor(self.obs_dim,self.num_lanes, self.num_phases, hidden_sizes[0])
        for k,value in self.oldpi.named_parameters():
            value.requires_grad=False

    #intersection 是intersection的个数
    #obs:12* 21  inters:12
    def step(self, state_input,all_phase_state,mask):
        with torch.no_grad():
            pi = self.pi(state_input,all_phase_state,mask,)
        return pi

    def get_v(self,obs,intersection):
        v = self.v(obs,intersection)
        return v

    # def act(self, obs):
    #     return self.step(obs)[0]

    #A优势函数 减去了基线 base
    def compute_advantage(self,state,reward,intersection):
        v=self.v(state,intersection)
        v=torch.reshape(v,[-1,1])

        return reward-v

    def update_oldpi(self):
        print(self.oldpi.load_state_dict)
        self.oldpi.load_state_dict(self.pi.state_dict())
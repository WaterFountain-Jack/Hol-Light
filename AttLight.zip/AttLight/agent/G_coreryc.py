import math

import numpy as np

import torch
import torch.nn as nn
from torch.nn import Transformer
from torch.autograd import Variable
from torch.distributions.normal import Normal
from torch.distributions.categorical import Categorical

from torch.nn import functional as F




class Actor(nn.Module):

    def _distribution(self, obs):
        raise NotImplementedError

    def _log_prob_from_distribution(self, pi, act):
        raise NotImplementedError

    def forward(self, obs,intersection,raw,col, act=None):
        # Produce action distributions for given observations, and
        # optionally compute the log likelihood of given actions under
        # those distributions.
        pi = self._distribution(obs)
        logp_a = None
        if act is not None:
            logp_a = self._log_prob_from_distribution(pi, act)
        return pi, logp_a

#维度变化为hidden_sizes
class Actor_front2(nn.Module):
    def __init__(self, obs_dim, hidden_sizes):
        super(Actor_front2, self).__init__()

        weight_tensor=torch.randn(obs_dim,hidden_sizes)
        bais_tensor=torch.randn(hidden_sizes)
        self.weights=nn.Parameter(weight_tensor,requires_grad=True)
        self.bais=nn.Parameter(bais_tensor,requires_grad=True)
        nn.init.normal_(self.weights, mean=0, std=1)
        nn.init.constant_(self.bais, val=0.1)


    def forward(self, x):
        return torch.matmul(x,self.weights)+self.bais

class MLPCategoricalActor(Actor):
    def __init__(self, state_input_dim,num_lanes, num_phases, hidden_sizes):
        super().__init__()
        self.state_input_dim=state_input_dim
        self.num_lanes = num_lanes
        self.num_phases=num_phases
        self.hidden_sizes=hidden_sizes

        #全连接层，维度变为 hidden_sizes
        self.actor1=Actor_front2(state_input_dim, hidden_sizes)

        #用于第一次lstm网络，压缩state_input_dim
        self.logits1 = nn.LSTM(hidden_sizes, hidden_sizes, batch_first=True, bidirectional=False)


        #第二部分的lstm
        self.actor11 = Actor_front2(num_lanes,hidden_sizes)
        #第二部分的lstm
        self.logits11 = nn.LSTM(hidden_sizes*2, hidden_sizes, batch_first=True, bidirectional=False)
        #把all_phase_input 的相位扩展成hidden_sizes
        self.actor22 = Actor_front2(self.num_lanes, hidden_sizes)
        #把价值压缩成1
        self.actor33 = Actor_front2(hidden_sizes, 1)
        self.mlp = Actor_front2(hidden_sizes,self.num_phases)

        # self.softmax = nn.Softmax(dim=1)

    def mysfotmax(self,x, mask):
        x = torch.exp(x)
        x = torch.mul(x, torch.tensor(mask))
        sum = torch.sum(x, dim=1)
        sum = torch.unsqueeze(sum, dim=1)
        sum = [sum for i in range(len(mask[0]))]
        sum = torch.cat(sum, dim=1)
        x = torch.div(x, torch.as_tensor(sum))
        return x


    #obs：12*21
    def forward(self, state_input,all_phase_state, mask,intersection):
        state_input = torch.reshape(state_input, [-1, self.state_input_dim])
        out1 = self.actor1(state_input)
        if(len(out1.shape)==2):
            [1,12,64]
            out1=out1.unsqueeze(dim=0)
        out1=torch.reshape(out1, [-1, intersection, self.hidden_sizes])
        batch = len(out1)
        #[1,64]
        h0=torch.zeros(1,batch,self.hidden_sizes)
        #[1,64]
        c0=torch.zeros(1 ,batch,self.hidden_sizes)
        #[1,12,64] 第一次lstm ，压缩state_input_dim
        out2,_=self.logits1(out1, (h0, c0))
        # [12,64] 第一次lstm ，压缩state_input_dim
        out2=torch.reshape(out2, [-1, self.hidden_sizes])

        out33 = self.mlp(out2)
        out33 = self.mysfotmax(out33, mask)

        # #从lan_num变为64位
        # all_phase_state = self.actor22(all_phase_state)
        # #记录之前的shape
        # all_phase_state_shape = all_phase_state.shape
        #
        # #复制自己变得维度和all_phase_state_shape 一样
        # out2 = torch.stack([out2 for i in range(all_phase_state_shape[1])],axis = 1)
        # #记录自己之前的维度，应该和all_phase_state_shape一样
        # out2_shape= out2.shape
        #
        # #变成2维度的方便使用torch.hstack
        #
        # out2 = torch.reshape(out2,[-1,self.hidden_sizes])
        # all_phase_state = torch.reshape(all_phase_state, [-1, self.hidden_sizes])
        #
        # #把all_phase_state和out2拼接在一起
        #
        # input11 = torch.hstack([all_phase_state,out2])
        # #变回原来的形状[iter,num_phase,hidden_sizes*2]
        # input11 = torch.reshape(input11,[all_phase_state_shape[0],-1, self.hidden_sizes*2])
        #
        #
        #
        # # print("all_phase_state:",all_phase_state)
        #
        # # [12,num_phases,hidden_sizes]
        # out11,_ = self.logits11(input11)
        #
        # ## [12,num_phases,1]
        # out22 = self.actor33(out11)
        #
        # #[12,num_phase]
        # out22 = torch.squeeze(out22)
        # # #乘以mask矩阵
        # # out22 = torch.mul(out22,torch.tensor(mask))
        #
        # out33 = self.mysfotmax(out22,mask)


        return out33

    def _log_prob_from_distribution(self, pi, act):
            return pi.log_prob(act)


class MLPCritic(nn.Module):

    def __init__(self, obs_dim, hidden_sizes, activation):
        super().__init__()
        self.l1 = nn.Linear(obs_dim,100)
        a=self.l1.weight
        nn.init.normal_(a,mean=0,std=0.01)
        b=self.l1.bias
        nn.init.constant_(b,val=0.01)
        self.v= nn.Linear(100,1)
        self.v_net=nn.Sequential(self.l1, self.v)

    def forward(self, obs,intersection):
        return self.v_net(obs)  # Critical to ensure v has right shape.

class MLPActorCritic(nn.Module):

    ##observation_space:21 action_space:4
    def __init__(self, observation_space, num_lanes,num_phases,
                 hidden_sizes=(64, 64), activation=nn.Tanh):
        super().__init__()
        #21
        self.obs_dim = observation_space
        ##最后输出的维度是1
        self.v = MLPCritic(self.obs_dim, hidden_sizes, activation)
        self.num_lanes = num_lanes
        self.num_phases = num_phases
        ###obs_dim:21 action_space:4 hidden_sizes[0]:64
        self.pi = MLPCategoricalActor(self.obs_dim,self.num_lanes, self.num_phases, hidden_sizes[0])
        self.oldpi=MLPCategoricalActor(self.obs_dim,self.num_lanes, self.num_phases, hidden_sizes[0])
        for k,value in self.oldpi.named_parameters():
            value.requires_grad=False

    #intersection 是intersection的个数
    #obs:12* 21  inters:12
    def step(self, state_input,all_phase_state,mask,intersection):
        with torch.no_grad():


            pi = self.pi(state_input,all_phase_state,mask, intersection)

        return pi

    def get_v(self,obs,intersection):
        v = self.v(obs,intersection)
        return v

    # def act(self, obs):
    #     return self.step(obs)[0]

    #A优势函数 减去了基线 base
    def compute_advantage(self,state,reward,intersection):
        v=self.v(state,intersection)
        v=torch.reshape(v,[-1,1])

        return reward-v

    def update_oldpi(self):
        print(self.oldpi.load_state_dict)
        self.oldpi.load_state_dict(self.pi.state_dict())
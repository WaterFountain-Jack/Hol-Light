import numpy as np
import torch
from torch.optim import Adam
import time
import agent.Attention_core as core
import torch.nn as nn
import random
# import core2 as core
import copy
import csv

GAMMA = 0.8
A_LR = 0.0005
C_LR = 0.0005

# A_LR = 0.001
# C_LR = 0.001
LAMBDA=0.5
A_UPDATE_STEPS = 10
C_UPDATE_STEPS = 10
EPSILON=0.2
KL_TARGET=0.01

class AttentionLightManyFeatures(object):
    ##维度为2 [N,numinter]

    def __init__(self, obs_dim=32, num_intersection=1,num_lanes = 3,num_phases = 8):

        self.obs_dim = obs_dim * 3
        self.num_intersection=num_intersection
        self.num_phases = num_phases

        self.num_lanes = num_lanes
        self.num_phases = num_phases

        #[41,12]
        self.buffer_a = []
        #[41,12,25]
        self.buffer_state = []
        #[41,12,numphase,numlane]
        self.buffer_s1 = []

        self.buffer_s2 = []
        #[41,12]
        self.buffer_r = []
        self.ac = core.MLPActorCritic(self.obs_dim, self.num_lanes,self.num_phases)

        self.pi_optimizer = Adam(self.ac.pi.parameters(), lr=A_LR)
        self.vf_optimizer = Adam(self.ac.v.parameters(), lr=C_LR)

    def th_gather_hd(self,x,coords):
        x=x.contiguous()
        inds=coords.mv(torch.LongTensor(x.stride()))
        x_gather=torch.index_select(x.contiguous().view(-1),0,inds)
        return x_gather

    def compute_loss_pi(self, s0, s1, s2,s3, a, adv):

        pi = self.ac.pi(s0, s1, s2,s3)
        # v(s)[492,1] 过去v
        old_pi=self.ac.oldpi(s0, s1, s2,s3)
        #[]
        pi_resize = torch.reshape(pi, [-1, self.num_phases])
        oldpi_resize = torch.reshape(old_pi, [-1, self.num_phases])

        #[[492],[492]] 前面全是0-491， 后面是1  功能是获得a的索引
        a_indices = torch.stack(
            [torch.arange(0,(torch.reshape(a, [-1])).shape[0]), torch.reshape(a, [-1])],dim=1)
        a_indices=a_indices.long()

        #获得当前action的概率
        pi_prob = self.th_gather_hd(pi_resize,a_indices)
        # 获得之前action的概率
        oldpi_prob = self.th_gather_hd(oldpi_resize,a_indices)

        pi_log=torch.log(pi_prob)
        # print(pi_log)
        oldpi_log=torch.log(oldpi_prob)
        # print(oldpi_log)

        ratio =torch.reshape((torch.exp(pi_log-oldpi_log)),[-1,1]).mean(dim=1)
        ratio=torch.reshape(ratio,[-1,self.num_intersection])
        # print(ratio)
        adv=torch.reshape(adv,[-1,self.num_intersection])
        clip_adv = torch.clamp(ratio, 1 - EPSILON, 1 + EPSILON) * adv
        loss_pi = -torch.mean(torch.min(ratio * adv, clip_adv))

        return loss_pi

    def choose_action(self,state):


        prob_temp = self.ac.step(torch.as_tensor(state[0], dtype=torch.float32),
                                 torch.as_tensor(state[1], dtype=torch.float32),
                                 torch.as_tensor(state[2], dtype=torch.float32),
                                 state[3])
        _action=[]
        ##***按照概率选取，并不是按照最大概率的选取
        for i in range(self.num_intersection):
            p = np.array(prob_temp[i])
            action_temp = np.random.choice(range(prob_temp[i].shape[0]), p=p.ravel())
            _action.append(action_temp)
        return _action

    def experience_storage(self, state, a, r):
        self.buffer_state.append(state)
        self.buffer_a.append(a)
        self.buffer_r.append(r)

    def empty_buffer(self):
        del self.buffer_state, self.buffer_s1,self.buffer_s2,self.buffer_r, self.buffer_a
        self.buffer_state, self.buffer_s1,self.buffer_s2,self.buffer_r, self.buffer_a,= [], [], [],[],[]

    #input :[12,25]
    def trajction_process(self, state):
        #使用一个mlp层直接用s算出来的v？[12,1]   #这里用当前相位的来进行计算了，看看能不能使用平均的方法这些来进行计算
        v_state = self.ac.get_v(torch.as_tensor(state,dtype=torch.float32),self.num_intersection)
        #[12,1]
        v_state=v_state.detach().numpy()
        #原本的buffer_r[41,12]  处理后：[41,12] 值没有变化
        buffer_r = np.mean(np.array(self.buffer_r).reshape([-1,1]), axis= 1).reshape([-1,int(self.num_intersection)])
        #12个[]
        buffer = [[] for i in range(self.num_intersection)]
        #-1表示从右往左取值
        #buffer_r变成了r的累加值，从后往前加
        for r in buffer_r[::-1]:
            for i in range(int(self.num_intersection)):
                v_state[i] = (r[i] + GAMMA * v_state[i])
                buffer[i].append(copy.deepcopy(v_state[i]))
        for i in range(int(self.num_intersection)):
            #记得把之前的结果给返回正确的顺序
            buffer[i].reverse()
        # [41,12,1] 蒙特卡罗算法算出来的v值
        out = np.stack([buffer[k] for k in range(int(self.num_intersection))], axis=1)
        #[41*12] buffer_r保存的是v(s)的值
        self.buffer_r = np.array(out).reshape([-1])

    def update(self,state):
        # state = state[0]
        #buffer_r算出来的是 t-T r + γv[s0]
        self.trajction_process(state)
        s0 = [s[0] for s in self.buffer_state]
        s1 = [s[1] for s in self.buffer_state]
        s2 = [s[2] for s in self.buffer_state]
        s3 = [s[3] for s in self.buffer_state]

        s0 = torch.as_tensor(np.vstack(s0), dtype=torch.float32)
        s1 = torch.as_tensor(np.vstack(s1), dtype=torch.float32)
        s2 = torch.as_tensor(np.vstack(s2), dtype=torch.float32)
        r = torch.as_tensor(np.vstack(self.buffer_r),dtype=torch.float32)
        a = torch.as_tensor(np.array(self.buffer_a).reshape([-1]),dtype=torch.float32)

        self.ac.update_oldpi()  #把现在pi的更新到oldpi中去
        adv=self.ac.compute_advantage(s0,r,self.num_intersection).detach().numpy()
        adv=torch.as_tensor(adv,dtype=torch.float32)

        #actor
        # Train policy with multiple steps of gradient descent
        print("actor loss:")
        for i in range(A_UPDATE_STEPS):
            self.pi_optimizer.zero_grad()
            loss_pi= self.compute_loss_pi(s0,s1,s2,s3,a,adv) #***这里加了梯度裁剪
            nn.utils.clip_grad_norm_(self.ac.pi.parameters(), max_norm=5, norm_type=2)
            loss_pi.backward()
            print(loss_pi)
            self.pi_optimizer.step()


        print("critic loss:")
        #critic
        # Value function learning
        for i in range(C_UPDATE_STEPS):
            self.vf_optimizer.zero_grad()
            adv = self.ac.compute_advantage(s0, r,self.num_intersection)
            loss_v = torch.square(adv).mean()
            loss_v.backward()
            print(loss_v)
            self.vf_optimizer.step()

        self.empty_buffer()
    def save(self, path):
        torch.save(self.ac, path)  # 保存整个模型

    def load(self, path):
        self.ac = torch.load(path)  # 加载模型
